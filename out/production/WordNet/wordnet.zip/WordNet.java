import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.RedBlackBST;

import java.util.ArrayList;
import java.util.Stack;

public class WordNet {

    private Digraph dg;
    private ArrayList<String> words;
    private RedBlackBST<String, String> bst;

    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null) throw new IllegalArgumentException("constructor argument is null");
        In syn = new In(synsets);
        In hyp = new In(hypernyms);
        words = new ArrayList<>();
        bst = new RedBlackBST<>();
        while (syn.hasNextLine()) {
            String line = syn.readLine();
            words.add(line.split(",")[1]);
            String[] linearr = line.split(",")[1].split(" ");
            for (int i = 0; i < linearr.length; i++) {
                bst.put(linearr[i], line.split(",")[0] + "-" + "i");
            }

        }
        dg = new Digraph(words.size());
        while (hyp.hasNextLine()) {
            String[] ind = hyp.readLine().split(",");
            for (int i = 1; i < ind.length; i++) {
                dg.addEdge(Integer.parseInt(ind[0]), Integer.parseInt(ind[i]));
            }
        }

    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        Stack<String> nouns = new Stack<>();
        for (String word : bst.keys()) {
            nouns.push(word);
        }
        return nouns;
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        if (word == null) throw new IllegalArgumentException("word is null");
        return bst.contains(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        SAP sap = new SAP(dg);
        int a = indexOf(nounA);
        int b = indexOf(nounB);
        if (a == -1 || b == -1) throw new IllegalArgumentException("word is not in wordnet");
        return sap.length(a, b);
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        int a = indexOf(nounA);
        int b = indexOf(nounB);
        if (a == -1 || b == -1) throw new IllegalArgumentException("word is not in wordnet");
        SAP sap = new SAP(dg);
        int index = sap.ancestor(a, b);
        if (index == -1) return null;
        return words.get(index);
    }

    private int indexOf(String noun) {
        if (noun == null) throw new IllegalArgumentException("word is null");
        if (!bst.contains(noun)) return -1;
        return Integer.parseInt(bst.get(noun).split("-")[0]);
    }


    // do unit testing of this class
    public static void main(String[] args) {
        String synsets = "txtfiles\\synsets.txt";
        String hypernyms = "txtfiles\\hypernyms.txt";
        WordNet w = new WordNet(synsets, hypernyms);
//        System.out.println(w.dg);
        System.out.println(w.isNoun("anamorphosis"));
    }
}
